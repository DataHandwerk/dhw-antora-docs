# Building

To build this repo from the sources (you'll need `git` and Java 11+ installed)...

```
git clone https://github.com/structurizr/cli.git structurizr-cli
cd structurizr-cli
./gradlew
```